namespace FastFood.Models.Enums
{
	public enum OrderType
	{
		ForHere,
		Takeaway
	}
}